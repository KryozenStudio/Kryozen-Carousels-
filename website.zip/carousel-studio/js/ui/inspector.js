// Inspector: slide fields, design (palette, type, shape), media and branding. Static markup lives in index.html;
// this module builds the data-driven bits, binds events and keeps controls in sync with the project.
import { getProject, ui, commit, historyAssetIds } from '../state.js';
import { KINDS, FIELDS, PALETTES, PAIRINGS, TEXTURES, GRADIENTS, PRESETS, FONTS, FONT_CATS, EL_LABELS, fontStack } from '../schema.js';
import { TEMPLATES } from '../templates/index.js';
import { resolve, mediaModeFor } from '../render.js';
import { addImage, urlOf, gc } from '../assets.js';
import { $, $$, normHex } from '../util.js';
import { toast } from './toast.js';

let hooks = { openGallery() {} };
const cur = () => getProject().slides[ui.slide];

const setPath = (o, path, v) => {
  const k = path.split('.');
  let t = o;
  for (let i = 0; i < k.length - 1; i++) t = t[k[i]];
  t[k[k.length - 1]] = v;
};
const getPath = (o, path) => path.split('.').reduce((a, k) => a?.[k], o);

/* ---------- tabs ---------- */
export function setTab(name) {
  $$('.tabs [role=tab]').forEach((t) => {
    const on = t.dataset.tab === name;
    t.setAttribute('aria-selected', on ? 'true' : 'false');
    t.tabIndex = on ? 0 : -1;
  });
  $$('#panels section').forEach((s) => (s.hidden = s.dataset.panel !== name));
  $('#panels').scrollTop = 0;
  const insp = $('#insp');
  if (insp.dataset.open === '0') setOpen(true);
}
function setOpen(open) {
  const insp = $('#insp');
  insp.dataset.open = open ? '1' : '0';
  $('#collapse').setAttribute('aria-expanded', open ? 'true' : 'false');
}

/* ---------- build dynamic controls ---------- */
function build() {
  $('#kindChips').innerHTML = Object.entries(KINDS)
    .map(([k, v]) => `<button class="chip" role="radio" data-kind="${k}" aria-checked="false">${v.label}</button>`)
    .join('');

  $('#slideFields').innerHTML = Object.entries(FIELDS)
    .map(([k, f]) => {
      const id = 'sf-' + k;
      const ctl = f.kind === 'line' ? `<input type="text" id="${id}" data-sf="${k}" maxlength="${f.max}" placeholder="${f.ph}" autocomplete="off">` : `<textarea id="${id}" data-sf="${k}" maxlength="${f.max}" placeholder="${f.ph}" rows="${f.rows || 2}"></textarea>`;
      return `<div class="field" data-fieldrow="${k}"><label class="lbl" for="${id}">${f.label}</label>${ctl}</div>`;
    })
    .join('');

  $('#palettes').innerHTML = PALETTES.map((p) => `<button class="sw" role="radio" data-pal="${p.id}" aria-checked="false" aria-label="${p.name}" title="${p.name}" style="--b:${p.bg};--t:${p.text};--a:${p.accent}"></button>`).join('');
  $('#textures').innerHTML = TEXTURES.map((t) => `<button class="chip" role="radio" data-tex="${t.id}" aria-checked="false">${t.id === 'none' ? 'No texture' : t.name}</button>`).join('');
  $('#gradients').innerHTML = GRADIENTS.map((t) => `<button class="chip" role="radio" data-grad="${t.id}" aria-checked="false">${t.id === 'none' ? 'No gradient' : t.name}</button>`).join('');
  const groups = {};
  for (const n of Object.keys(FONTS)) (groups[FONT_CATS[n]] ||= []).push(n);
  const opts = Object.entries(groups).map(([g, l]) => `<optgroup label="${g}">${l.map((n) => `<option value="${n}">${n}</option>`).join('')}</optgroup>`).join('');
  $('#fDisp').innerHTML = opts;
  $('#fBody').innerHTML = opts;
  $('#pairs').innerHTML = PAIRINGS.map(
    (p) => `<button class="pair" role="radio" data-pair="${p.id}" aria-checked="false"><span class="a" style="font-family:${fontStack(p.display)};font-weight:${Math.min(p.hw, FONTS[p.display].w[1])}">${p.name}</span><span class="b" style="font-family:${fontStack(p.body)}">${p.display} + ${p.body}</span></button>`
  ).join('');
}

/* ---------- sync controls <- project ---------- */
const setVal = (el, v) => {
  if (!el || el === document.activeElement) return;
  if (el.type === 'checkbox') el.checked = !!v;
  else if (el.value !== String(v)) el.value = v;
};
const checked = (sel, pred) => $$(sel).forEach((b) => b.setAttribute('aria-checked', pred(b) ? 'true' : 'false'));

export function syncInspector() {
  const p = getProject();
  const s = cur();
  const r = resolve(p);

  checked('#kindChips .chip', (b) => b.dataset.kind === s.kind);
  const fields = KINDS[s.kind].fields;
  $$('[data-fieldrow]').forEach((row) => (row.hidden = !fields.includes(row.dataset.fieldrow)));
  $$('[data-sf]').forEach((el) => setVal(el, s.fields[el.dataset.sf]));

  $('#tplName').textContent = r.t.name;
  checked('#palettes .sw', (b) => b.dataset.pal === (p.theme.palette || r.t.palette));
  checked('#textures .chip', (b) => b.dataset.tex === r.texture);
  checked('#gradients .chip', (b) => b.dataset.grad === r.gradient);
  checked('#pairs .pair', (b) => b.dataset.pair === r.pair.id && !p.type.display && !p.type.body);
  const txt = r.colors.text;
  const shownColor = { bg: r.colors.bg, surface: r.colors.surface, heading: r.colors.heading || txt, body: r.colors.body || txt, accent: r.colors.accent, tag: r.colors.tag || r.colors.accent, footer: r.colors.footer || txt };
  $$('[data-color]').forEach((el) => setVal(el, normHex(shownColor[el.dataset.color], '#000000')));
  setVal($('#fDisp'), r.display);
  setVal($('#fBody'), r.body);
  const g = p.theme.grad;
  $('[data-gon]').checked = g.on;
  $$('[data-gcol]').forEach((el) => ((el.disabled = !g.on), setVal(el, g[el.dataset.gcol])));
  setVal($('#gAng'), g.angle);
  $('#gAng').disabled = !g.on;
  $('[data-gout]').textContent = g.angle + '°';
  // position group
  const key = ui.el;
  const eo = (key && s.el[key]) || { x: 0, y: 0, a: null };
  $('#posGroup').dataset.empty = key ? '0' : '1';
  $('#elName').textContent = key ? EL_LABELS[key] : 'select a block on the slide';
  setVal($('#posX'), eo.x);
  setVal($('#posY'), eo.y);
  $$('[data-pout]').forEach((o) => (o.textContent = eo[o.dataset.pout]));
  checked('#posAlign button', (b) => b.dataset.pa === eo.a);
  checked('#vAlign button', (b) => b.dataset.va === (s.valign || 'auto'));

  const shown = { 'type.scale': p.type.scale, 'type.weight': r.weight, 'shape.radius': r.radius, 'shape.pad': r.pad, 'type.tracking': r.tracking, 'type.leading': r.leading, 'shape.gap': r.gap };
  $$('[data-bind]').forEach((el) => {
    const path = el.dataset.bind;
    setVal(el, path in shown ? shown[path] : getPath(p, path));
  });
  const wRange = $('#typeWeight');
  const [lo, hi] = FONTS[r.display].w;
  wRange.min = lo;
  wRange.max = hi;
  wRange.disabled = lo === hi;
  $$('[data-out]').forEach((o) => {
    const v = shown[o.dataset.out];
    const k = o.dataset.out;
    o.textContent = k === 'type.scale' ? Math.round(v * 100) + '%' : k === 'type.weight' ? v : k === 'type.tracking' ? (v * 100).toFixed(1) + '%' : k === 'type.leading' || k === 'shape.gap' ? (+v).toFixed(2) : (+v).toFixed(1);
  });
  $$('[data-seg]').forEach((g) => checked(`[data-seg="${g.dataset.seg}"] button`, (b) => b.dataset.v === String(getPath(p, g.dataset.seg))));

  // media
  const has = !!(s.media.asset && urlOf(s.media.asset));
  $('#mediaCtl').hidden = !has;
  const prev = $('#dropPrev');
  prev.hidden = !has;
  prev.style.backgroundImage = has ? `url("${urlOf(s.media.asset)}")` : '';
  $('#dropTitle').textContent = has ? 'Replace image' : 'Drop an image here';
  const mode = mediaModeFor(r.t, s.kind);
  $('#scrimField').hidden = mode !== 'bg';
  $('#mediaHint').textContent =
    mode === 'bg'
      ? 'This template uses the image as a full-bleed background. Drag it on the preview to reposition; Ctrl/Cmd + scroll or pinch to zoom.'
      : mode === 'frame'
        ? 'This template shows the image in a frame. Drag it on the preview to reposition; Ctrl/Cmd + scroll or pinch to zoom.'
        : 'This template does not use images on this slide type.';
  $$('[data-m]').forEach((el) => setVal(el, s.media[el.dataset.m]));
  $$('[data-mout]').forEach((o) => {
    const k = o.dataset.mout;
    o.textContent = k === 'zoom' ? s.media.zoom.toFixed(2) + '×' : Math.round(s.media[k] * (k === 'opacity' ? 100 : 1)) + '%';
  });
  checked('[data-mseg=fit] button', (b) => b.dataset.v === s.media.fit);

  $('#avatarClear').disabled = !p.brand.avatar;
  $('#mvL').disabled = ui.slide === 0;
  $('#mvR').disabled = ui.slide === p.slides.length - 1;
}

/* ---------- image import ---------- */
const collect = () => gc(historyAssetIds());

export async function setSlideImage(file) {
  const dz = $('#dropTitle');
  const old = dz.textContent;
  dz.textContent = 'Processing…';
  try {
    const { id } = await addImage(file);
    const sid = cur().id;
    commit(
      (p) => {
        const sl = p.slides.find((x) => x.id === sid);
        if (sl) Object.assign(sl.media, { asset: id, x: 50, y: 50, zoom: 1 });
      },
      { scope: 'slide', ids: [sid], source: 'media' }
    );
    collect();
  } catch (e) {
    toast(e.message || 'Could not add that image.');
    dz.textContent = old;
  }
}

async function setAvatar(file) {
  try {
    const { id } = await addImage(file);
    commit((p) => (p.brand.avatar = id), { scope: 'global', source: 'media' });
    collect();
  } catch (e) {
    toast(e.message || 'Could not add that image.');
  }
}

export const pickImage = () => {
  setTab('media');
  $('#file').click();
};

/* ---------- events ---------- */
function bind() {
  // tabs
  $$('.tabs [role=tab]').forEach((t) => (t.onclick = () => setTab(t.dataset.tab)));
  $('.tabs').addEventListener('keydown', (e) => {
    const tabs = $$('.tabs [role=tab]');
    const i = tabs.findIndex((t) => t.getAttribute('aria-selected') === 'true');
    if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
      const n = tabs[(i + (e.key === 'ArrowRight' ? 1 : tabs.length - 1)) % tabs.length];
      setTab(n.dataset.tab);
      n.focus();
      e.preventDefault();
    }
  });
  $('#collapse').onclick = () => setOpen($('#insp').dataset.open === '0');

  const panels = $('#panels');

  // slide kind + fields
  panels.addEventListener('click', (e) => {
    const k = e.target.closest('[data-kind]');
    if (k) {
      const kind = k.dataset.kind;
      commit(
        (p) => {
          const s = p.slides[ui.slide];
          s.kind = kind;
          const pre = PRESETS[kind] || {};
          for (const f of KINDS[kind].fields) if (!String(s.fields[f] || '').trim() && pre[f]) s.fields[f] = pre[f]; // never leaves a new type blank, never overwrites text
        },
        { scope: 'slide', ids: [cur().id] }
      );
      return;
    }
    const pal = e.target.closest('[data-pal]');
    if (pal) return commit((p) => ((p.theme.palette = pal.dataset.pal), (p.theme.overrides = {})), { scope: 'global' });
    const tex = e.target.closest('[data-tex]');
    if (tex) return commit((p) => (p.theme.texture = tex.dataset.tex), { scope: 'global' });
    const gr = e.target.closest('[data-grad]');
    if (gr) return commit((p) => (p.theme.gradient = gr.dataset.grad), { scope: 'global' });
    const pr = e.target.closest('[data-pair]');
    if (pr) return commit((p) => ((p.type.pairing = pr.dataset.pair), (p.type.weight = null), (p.type.display = null), (p.type.body = null), (p.type.tracking = null), (p.type.leading = null)), { scope: 'global' });
    const pa = e.target.closest('[data-pa]');
    if (pa && ui.el) {
      const id = cur().id;
      const key = ui.el;
      return commit((p) => {
        const s = p.slides.find((x) => x.id === id);
        s.el[key] = { x: 0, y: 0, ...s.el[key], a: pa.dataset.pa };
      }, { scope: 'slide', ids: [id] });
    }
    const va = e.target.closest('[data-va]');
    if (va) {
      const id = cur().id;
      return commit((p) => (p.slides.find((x) => x.id === id).valign = va.dataset.va === 'auto' ? null : va.dataset.va), { scope: 'slide', ids: [id] });
    }
    const sg = e.target.closest('[data-seg] button');
    if (sg) return commit((p) => setPath(p, sg.closest('[data-seg]').dataset.seg, sg.dataset.v), { scope: 'global' });
    const ms = e.target.closest('[data-mseg] button');
    if (ms) {
      const id = cur().id;
      return commit((p) => (p.slides.find((x) => x.id === id).media[ms.closest('[data-mseg]').dataset.mseg] = ms.dataset.v), { scope: 'slide', ids: [id] });
    }
  });

  panels.addEventListener('input', (e) => {
    const el = e.target;
    if (el.dataset.sf) {
      const id = cur().id;
      const f = el.dataset.sf;
      commit((p) => (p.slides.find((x) => x.id === id).fields[f] = el.value), { key: `sf:${id}:${f}`, scope: 'slide', ids: [id], source: 'sidebar' });
    } else if (el.dataset.bind) {
      const path = el.dataset.bind;
      const v = el.type === 'checkbox' ? el.checked : el.type === 'range' ? parseFloat(el.value) : el.value;
      commit((p) => setPath(p, path, v), { key: 'b:' + path, scope: 'global', source: 'sidebar' });
    } else if (el.dataset.pos && ui.el) {
      const id = cur().id;
      const key = ui.el;
      const ax = el.dataset.pos;
      commit((p) => {
        const s = p.slides.find((x) => x.id === id);
        s.el[key] = { x: 0, y: 0, a: null, ...s.el[key], [ax]: parseFloat(el.value) };
      }, { key: `el:${id}:${key}:${ax}`, scope: 'slide', ids: [id], source: 'sidebar' });
    } else if (el.dataset.gon !== undefined) {
      commit((p) => (p.theme.grad.on = el.checked), { scope: 'global' });
    } else if (el.dataset.gcol) {
      commit((p) => (p.theme.grad[el.dataset.gcol] = el.value), { key: 'g:' + el.dataset.gcol, scope: 'global', source: 'sidebar' });
    } else if (el.dataset.gang !== undefined) {
      commit((p) => (p.theme.grad.angle = parseFloat(el.value)), { key: 'g:angle', scope: 'global', source: 'sidebar' });
    } else if (el.dataset.font) {
      commit((p) => (p.type[el.dataset.font] = el.value), { scope: 'global' });
    } else if (el.dataset.color) {
      const k = el.dataset.color;
      commit((p) => (p.theme.overrides[k] = el.value), { key: 'c:' + k, scope: 'global', source: 'sidebar' });
    } else if (el.dataset.m) {
      const id = cur().id;
      const k = el.dataset.m;
      commit((p) => (p.slides.find((x) => x.id === id).media[k] = parseFloat(el.value)), { key: `m:${id}:${k}`, scope: 'slide', ids: [id], source: 'sidebar' });
    }
  });

  $('#colorReset').onclick = () => commit((p) => (p.theme.overrides = {}), { scope: 'global' });
  $('#designReset').onclick = () =>
    commit(
      (p) => {
        p.theme = { ...p.theme, palette: null, overrides: {}, texture: null, gradient: null, grad: { ...p.theme.grad, on: false } };
        p.type = { ...p.type, pairing: null, display: null, body: null, tracking: null, leading: null, weight: null, scale: 1, align: 'auto', caps: 'auto' };
        p.shape = { radius: null, pad: null, gap: null };
      },
      { scope: 'global' }
    );
  $('#tplBtn').onclick = () => hooks.openGallery();
  $('#posReset').onclick = () => {
    const id = cur().id;
    const key = ui.el;
    if (key) commit((p) => delete p.slides.find((x) => x.id === id).el[key], { scope: 'slide', ids: [id] });
  };

  // media
  const file = $('#file');
  const drop = $('#drop');
  drop.onclick = () => file.click();
  drop.onkeydown = (e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), file.click());
  file.onchange = () => {
    if (file.files[0]) setSlideImage(file.files[0]);
    file.value = '';
  };
  $('#mRemove').onclick = () => {
    const id = cur().id;
    commit((p) => (p.slides.find((x) => x.id === id).media.asset = null), { scope: 'slide', ids: [id] });
    collect();
  };
  const af = $('#avatarFile');
  $('#avatarBtn').onclick = () => af.click();
  af.onchange = () => {
    if (af.files[0]) setAvatar(af.files[0]);
    af.value = '';
  };
  $('#avatarClear').onclick = () => {
    commit((p) => (p.brand.avatar = null), { scope: 'global' });
    collect();
  };

  // drag & drop and paste anywhere
  const isImg = (dt) => dt && [...dt.items].some((i) => i.kind === 'file' && i.type.startsWith('image/'));
  window.addEventListener('dragover', (e) => {
    if (!isImg(e.dataTransfer)) return;
    e.preventDefault();
    drop.classList.toggle('over', !!e.target.closest?.('#drop'));
  });
  window.addEventListener('dragleave', (e) => !e.relatedTarget && drop.classList.remove('over'));
  window.addEventListener('drop', (e) => {
    drop.classList.remove('over');
    const f = e.dataTransfer && [...e.dataTransfer.files].find((x) => x.type.startsWith('image/'));
    if (!f) return;
    e.preventDefault();
    setSlideImage(f);
    setTab('media');
  });
  window.addEventListener('paste', (e) => {
    if (e.target.closest?.('input,textarea,[contenteditable]')) return;
    const f = [...(e.clipboardData?.files || [])].find((x) => x.type.startsWith('image/'));
    if (f) {
      e.preventDefault();
      setSlideImage(f);
    }
  });

  $('#projName').addEventListener('input', (e) => commit((p) => (p.name = e.target.value), { key: 'name', scope: 'meta', source: 'sidebar' }));
}

export function initInspector(h) {
  hooks = { ...hooks, ...h };
  build();
  bind();
  setTab('slide');
}

export { TEMPLATES };
